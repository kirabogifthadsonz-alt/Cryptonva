# CycleVest design direction

## Design movement
Quiet conviction: a premium, restrained dark fintech dashboard that feels calm and legible rather than speculative or casino-like.

## Core principles
1. Make balances and status immediately scannable.
2. Treat risk language as first-class UI, not footnotes.
3. Use red as an intentional action accent, never as a promise of profit.
4. Keep every interaction reversible and prototype-safe.

## Color philosophy
Near-black `#08090B` grounds the interface. Charcoal `#141619` cards and `#2A2D31` borders create a layered surface system. `#F04444` / `#FF5A5F` are used for primary actions and active navigation. Warm white `#F7F7F5` and muted gray `#9EA3AA` preserve contrast. Green and amber are only paired with explicit text labels.

## Layout paradigm
A centered, roomy dashboard canvas with a sticky desktop rail-like bottom navigation translated into a fixed mobile bottom bar. Cards use rounded corners, clear grouping, and compact stat clusters. The first screen prioritizes balances, then actions, then active cycles, then the testimonial feed.

## Signature elements
- CycleVest monogram: a geometric red orbit/loop mark in a square field.
- Small uppercase eyebrow labels for category and qualification.
- Risk chips and status badges with text, never color alone.
- A thin red activity bar on the active cycle cards.

## Interaction philosophy
Tactile, immediate, and honest. Tabs switch without page reload. Filters update the visible cycle list. Deposit, withdraw, report, and demo-investment actions open informative modals with no side effects.

## Animation
Subtle entrance lift and progress-bar transitions only. No flashing, confetti, or attention-grabbing profit animations.

## Typography system
Use Inter with system fallbacks. Large numeric balances are bold and tightly tracked. Body copy stays at readable 14–16px. Uppercase microcopy uses generous letter spacing.

## Brand essence
A transparent prototype for understanding cycle-based crypto investing—not a promise of returns.

## Brand voice
Clear, measured, specific, and compliance-aware. Prefer “illustrative,” “projected,” and “not guaranteed” over promotional language.

## Wordmark/logo
CycleVest wordmark paired with the red orbit mark. The same mark is used in the header and favicon.

## Signature brand color
Primary red `#F04444`, supported by bright red `#FF5A5F` for hover and focus states.
