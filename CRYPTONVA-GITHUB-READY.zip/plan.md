# CycleVest MVP implementation plan

## Outcome
Build a responsive, mobile-first investor portal prototype using local mock data only. The experience is intentionally non-transactional: all deposits, withdrawals, and demo investments explain that integrations are not enabled and do not change balances.

## Architecture
- **Serving arrangement:** static single-page application (SPA/CSR). All requested product data is local mock data and can be produced at build time; no server, database, payment, wallet, custody, KYC, or transaction capability is needed.
- **Runtime:** Node's built-in HTTP server serves the static root on port 3000 for Preview. No external dependencies are required.
- **Routing:** Browser-managed view state uses Home, Earn, Income, and Profile tabs; `/` is the only application page route. `public/manus-routes.json` declares `/`.
- **Caching:** Preview is development-only. If published later, versioned assets can be cached long-lived while the HTML shell remains revalidated; no private data or API cache is present.

## Project structure
- `server.js` — minimal static file server on `PORT` (default 3000).
- `index.html` — app shell, metadata, accessible landmarks, and modal host.
- `styles.css` — responsive dark visual system, layout, cards, navigation, modals, and breakpoints.
- `app.js` — typed-by-convention local mock data, view rendering, filters, modal behavior, and navigation state.
- `public/manus-routes.json` — Webdev route manifest.
- `public/cyclevest-mark.svg` — original project-specific logo/favicon artwork.
- `ideas.md` — accepted design direction.
- `app.config.ts` — project logo metadata.

## Verification
Use source inspection, `node --check app.js`, `node --check server.js`, and an HTTP readiness check against port 3000. Verify `/manus-routes.json` returns HTTP 200 JSON and that required strings and safety constraints are present in source. Use Webdev diagnostics registration supplied by the host; no browser/screenshot pass is needed unless a concrete rendered defect appears.
