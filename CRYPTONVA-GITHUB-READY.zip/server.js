const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { DatabaseSync } = require('node:sqlite');

const root = __dirname;
const dataDir = path.join(root, 'data');
const dbPath = process.env.CRYPTONVA_DB || path.join(dataDir, 'cryptonva.sqlite');
const port = Number(process.env.PORT || 3000);
const secureCookie = process.env.NODE_ENV === 'production';
const db = new DatabaseSync(dbPath);
const sessions = new Map();
const types = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.ico':'image/x-icon'};

fs.mkdirSync(dataDir,{recursive:true});
db.exec(`
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE, username TEXT NOT NULL UNIQUE,
  telecom TEXT NOT NULL, country TEXT NOT NULL, password_salt TEXT NOT NULL,
  password_hash TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS profiles (
  user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  full_name TEXT, phone TEXT, timezone TEXT, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS accounts (
  user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  currency TEXT NOT NULL DEFAULT 'USD', created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS ledger_entries (
  id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK(kind IN ('deposit','investment','investment_return','withdrawal','withdrawal_reversal','adjustment')),
  amount_cents INTEGER NOT NULL CHECK(amount_cents <> 0), reference_id TEXT,
  status TEXT NOT NULL DEFAULT 'posted' CHECK(status IN ('pending','posted','reversed','failed')),
  description TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_ledger_user_created ON ledger_entries(user_id, created_at DESC);
CREATE TABLE IF NOT EXISTS investment_cycles (
  id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plan_name TEXT NOT NULL, principal_cents INTEGER NOT NULL CHECK(principal_cents > 0),
  started_at TEXT NOT NULL, ends_at TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','completed','cancelled')),
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_cycles_user_status ON investment_cycles(user_id,status);
CREATE TABLE IF NOT EXISTS support_messages (
  id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  subject TEXT NOT NULL, message TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open', created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS notifications (
  id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL, body TEXT NOT NULL, type TEXT NOT NULL DEFAULT 'info', unread INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL
);
`);

function parseCookies(req){return Object.fromEntries((req.headers.cookie||'').split(';').filter(Boolean).map(pair=>{const i=pair.indexOf('=');return [pair.slice(0,i).trim(),decodeURIComponent(pair.slice(i+1).trim())]}));}
function cookie(name,value,{maxAge,clear=false}={}){const parts=[`${name}=${encodeURIComponent(value)}`,'Path=/','HttpOnly','SameSite=Lax'];if(maxAge!==undefined)parts.push(`Max-Age=${maxAge}`);if(secureCookie)parts.push('Secure');return parts.join('; ');}
function sendJson(res,status,payload,extra={}){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...extra});res.end(JSON.stringify(payload));}
function readBody(req){return new Promise((resolve,reject)=>{let body='';req.on('data',c=>{body+=c;if(body.length>100000)req.destroy();});req.on('end',()=>{try{resolve(JSON.parse(body||'{}'))}catch{reject(new Error('Invalid JSON body'))}});req.on('error',reject)});}
function safeText(v,max=160){return String(v??'').trim().slice(0,max)}
function validEmail(v){return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)}
function hashPassword(password,salt=crypto.randomBytes(16).toString('hex')){return {salt,hash:crypto.scryptSync(password,salt,64).toString('hex')}}
function passwordsMatch(password,user){const d=crypto.scryptSync(password,user.password_salt,64),s=Buffer.from(user.password_hash,'hex');return d.length===s.length&&crypto.timingSafeEqual(d,s)}
function currentUser(req){const token=parseCookies(req).cryptonva_session, s=token&&sessions.get(token);if(!s||s.expiresAt<Date.now()){if(token)sessions.delete(token);return null}return db.prepare('SELECT id,email,username,telecom,country,created_at FROM users WHERE id=?').get(s.userId)||null}
function createSession(user){const token=crypto.randomBytes(32).toString('hex');sessions.set(token,{userId:user.id,expiresAt:Date.now()+30*86400000});return token}
function publicUser(u){return {id:u.id,email:u.email,username:u.username,telecom:u.telecom,country:u.country,createdAt:u.created_at}}
function notify(userId,title,body,type='info'){db.prepare('INSERT INTO notifications(id,user_id,title,body,type,unread,created_at) VALUES(?,?,?,?,?,1,?)').run(crypto.randomUUID(),userId,title,body,type,new Date().toISOString())}
function ledger(userId,kind,cents,description,referenceId=null,status='posted'){db.prepare('INSERT INTO ledger_entries(id,user_id,kind,amount_cents,reference_id,status,description,created_at) VALUES(?,?,?,?,?,?,?,?)').run(crypto.randomUUID(),userId,kind,cents,referenceId,status,description,new Date().toISOString())}
function accountSummary(userId){
  const rows=db.prepare("SELECT COALESCE(SUM(CASE WHEN status='posted' THEN amount_cents ELSE 0 END),0) AS balance FROM ledger_entries WHERE user_id=?").get(userId);
  const invested=db.prepare("SELECT COALESCE(SUM(principal_cents),0) AS amount FROM investment_cycles WHERE user_id=? AND status='active'").get(userId);
  const accrued=db.prepare("SELECT COALESCE(SUM(amount_cents),0) AS amount FROM ledger_entries WHERE user_id=? AND kind='investment_return' AND status='posted'").get(userId);
  const available=Number(rows.balance)-Number(invested.amount);
  return {total:(Number(rows.balance)/100).toFixed(2),available:(available/100).toFixed(2),invested:(Number(invested.amount)/100).toFixed(2),accrued:(Number(accrued.amount)/100).toFixed(2)};
}
function parseCents(v){const n=Number(v);if(!Number.isFinite(n)||n<=0||n>100000000)return null;return Math.round(n*100)}
function safePath(urlPath){const decoded=decodeURIComponent(urlPath.split('?')[0]);const requested=decoded==='/'?'/index.html':decoded;const filePath=path.normalize(path.join(root,requested));return filePath.startsWith(root)?filePath:null}

async function api(req,res,url){
  const user=currentUser(req);
  if(url.pathname==='/api/health'&&req.method==='GET')return sendJson(res,200,{ok:true,service:'cryptonva',database:'sqlite',time:new Date().toISOString()});
  if(url.pathname==='/api/session'&&req.method==='GET')return sendJson(res,200,user?{authenticated:true,user:publicUser(user),balances:accountSummary(user.id)}:{authenticated:false});
  if(url.pathname==='/api/signup'&&req.method==='POST'){
    try{const b=await readBody(req),email=safeText(b.email,200).toLowerCase(),username=safeText(b.username,40),telecom=safeText(b.telecom,40),country=safeText(b.country,80),password=String(b.password||'');
      if(!validEmail(email))return sendJson(res,400,{error:'Enter a valid email address.'});if(!/^[a-zA-Z0-9_.-]{3,40}$/.test(username))return sendJson(res,400,{error:'Username must be 3–40 characters.'});if(telecom.length<3||!country)return sendJson(res,400,{error:'Phone and country are required.'});if(password.length<8)return sendJson(res,400,{error:'Password must be at least 8 characters.'});if(b.confirmPassword!==undefined&&password!==String(b.confirmPassword))return sendJson(res,400,{error:'Passwords do not match.'});if(b.terms!==true)return sendJson(res,400,{error:'You must accept the Terms and Conditions.'});
      if(db.prepare('SELECT id FROM users WHERE lower(email)=lower(?)').get(email))return sendJson(res,409,{error:'An account with that email already exists.'});if(db.prepare('SELECT id FROM users WHERE lower(username)=lower(?)').get(username))return sendJson(res,409,{error:'That username is already taken.'});
      const {salt,hash}=hashPassword(password),id=crypto.randomUUID(),now=new Date().toISOString();db.prepare('INSERT INTO users(id,email,username,telecom,country,password_salt,password_hash,created_at) VALUES(?,?,?,?,?,?,?,?)').run(id,email,username,telecom,country,salt,hash,now);db.prepare('INSERT INTO profiles(user_id,full_name,phone,timezone,updated_at) VALUES(?,?,?,?,?)').run(id,username,telecom,'Africa/Kampala',now);db.prepare('INSERT INTO accounts(user_id,currency,created_at) VALUES(?,?,?)').run(id,'USD',now);notify(id,'Welcome to CRYPTONVA','Your account has been created. Complete verification before financial features are enabled.');const u=db.prepare('SELECT id,email,username,telecom,country,created_at FROM users WHERE id=?').get(id),token=createSession(u);return sendJson(res,201,{user:publicUser(u),balances:accountSummary(id)},{'Set-Cookie':cookie('cryptonva_session',token,{maxAge:30*86400})});
    }catch(e){return sendJson(res,400,{error:e.message||'Could not create account.'})}
  }
  if(url.pathname==='/api/login'&&req.method==='POST'){try{const b=await readBody(req),username=safeText(b.username,40),password=String(b.password||''),u=db.prepare('SELECT * FROM users WHERE lower(username)=lower(?)').get(username);if(!u||!passwordsMatch(password,u))return sendJson(res,401,{error:'Incorrect username or password.'});const token=createSession(u);return sendJson(res,200,{user:publicUser(u),balances:accountSummary(u.id)},{'Set-Cookie':cookie('cryptonva_session',token,{maxAge:30*86400})})}catch(e){return sendJson(res,400,{error:e.message||'Could not log in.'})}}
  if(url.pathname==='/api/logout'&&req.method==='POST'){const t=parseCookies(req).cryptonva_session;if(t)sessions.delete(t);return sendJson(res,200,{ok:true},{'Set-Cookie':cookie('cryptonva_session','',{maxAge:0})})}
  if(!user)return sendJson(res,401,{error:'Authentication required.'});
  if(url.pathname==='/api/account'&&req.method==='GET')return sendJson(res,200,{user:publicUser(user),balances:accountSummary(user.id)});
  if(url.pathname==='/api/ledger'&&req.method==='GET'){const rows=db.prepare("SELECT id,kind,amount_cents AS amountCents,reference_id AS referenceId,status,description,created_at AS createdAt FROM ledger_entries WHERE user_id=? ORDER BY created_at DESC LIMIT 100").all(user.id);return sendJson(res,200,{entries:rows.map(x=>({...x,amount:(x.amountCents/100).toFixed(2)}))})}
  if(url.pathname==='/api/cycles'&&req.method==='GET'){const rows=db.prepare('SELECT id,plan_name AS planName,principal_cents AS principalCents,started_at AS startedAt,ends_at AS endsAt,status FROM investment_cycles WHERE user_id=? ORDER BY created_at DESC').all(user.id);return sendJson(res,200,{cycles:rows.map(x=>({...x,principal:(x.principalCents/100).toFixed(2)}))})}
  if(url.pathname==='/api/deposits'&&req.method==='POST'){const b=await readBody(req),cents=parseCents(b.amount);if(!cents)return sendJson(res,400,{error:'Enter a valid deposit amount.'});return sendJson(res,202,{error:'Payment rail is not connected yet. No funds were credited.',status:'pending_integration',amount:(cents/100).toFixed(2)})}
  if(url.pathname==='/api/withdrawals'&&req.method==='POST'){const b=await readBody(req),cents=parseCents(b.amount),available=Number(accountSummary(user.id).available)*100;if(!cents)return sendJson(res,400,{error:'Enter a valid withdrawal amount.'});if(cents>available)return sendJson(res,400,{error:'Insufficient available balance.'});return sendJson(res,202,{error:'Withdrawal rail is not connected yet. No funds were released.',status:'pending_integration',amount:(cents/100).toFixed(2)})}
  if(url.pathname==='/api/support'&&req.method==='POST'){const b=await readBody(req),subject=safeText(b.subject,160),message=safeText(b.message,4000);if(!subject||!message)return sendJson(res,400,{error:'Subject and message are required.'});const id=crypto.randomUUID();db.prepare('INSERT INTO support_messages(id,user_id,subject,message,status,created_at) VALUES(?,?,?,?,?,?)').run(id,user.id,subject,message,'open',new Date().toISOString());notify(user.id,'Support request received',subject);return sendJson(res,201,{id,status:'open'})}
  if(url.pathname==='/api/notifications'&&req.method==='GET'){const rows=db.prepare('SELECT id,title,body,type,unread,created_at AS createdAt FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 50').all(user.id);return sendJson(res,200,{notifications:rows.map(x=>({...x,unread:Boolean(x.unread)}))})}
  if(url.pathname==='/api/notifications/read-all'&&req.method==='POST'){db.prepare('UPDATE notifications SET unread=0 WHERE user_id=?').run(user.id);return sendJson(res,200,{ok:true})}
  if(url.pathname==='/api/profile'&&req.method==='GET'){const p=db.prepare('SELECT full_name AS name, phone, timezone FROM profiles WHERE user_id=?').get(user.id)||{};return sendJson(res,200,{profile:{...p,email:user.email,country:user.country}})}
  if(url.pathname==='/api/profile'&&req.method==='PUT'){const b=await readBody(req),name=safeText(b.name,120),phone=safeText(b.phone,40),timezone=safeText(b.timezone,80);if(!name)return sendJson(res,400,{error:'Full name is required.'});db.prepare('UPDATE profiles SET full_name=?,phone=?,timezone=?,updated_at=? WHERE user_id=?').run(name,phone,timezone,new Date().toISOString(),user.id);return sendJson(res,200,{ok:true,profile:{name,email:user.email,country:user.country,phone,timezone}})}
  if(url.pathname==='/api/investments'&&req.method==='POST'){const b=await readBody(req),plan=safeText(b.planName,120),cents=parseCents(b.amount),days=Math.max(1,Math.min(365,Number(b.durationDays)||1));if(!plan||!cents)return sendJson(res,400,{error:'Plan and amount are required.'});const available=Number(accountSummary(user.id).available)*100;if(cents>available)return sendJson(res,400,{error:'Insufficient available balance.'});const id=crypto.randomUUID(),now=new Date(),end=new Date(now.getTime()+days*86400000).toISOString();db.exec('BEGIN IMMEDIATE');try{ledger(user.id,'investment',-cents,`Investment started: ${plan}`,id);db.prepare('INSERT INTO investment_cycles(id,user_id,plan_name,principal_cents,started_at,ends_at,status,created_at) VALUES(?,?,?,?,?,?,?,?)').run(id,user.id,plan,cents,now.toISOString(),end,'active',now.toISOString());notify(user.id,'Investment started',`${plan} has been funded.`,'success');db.exec('COMMIT')}catch(e){db.exec('ROLLBACK');throw e}return sendJson(res,201,{id,status:'active',cycle:{planName:plan,principal:(cents/100).toFixed(2),startedAt:now.toISOString(),endsAt:end},balances:accountSummary(user.id)})}
  return sendJson(res,404,{error:'Not found'});
}
const server=http.createServer(async(req,res)=>{try{const url=new URL(req.url||'/',`http://${req.headers.host||'localhost'}`);if(url.pathname.startsWith('/api/')){await api(req,res,url);return}const file=safePath(req.url||'/');if(!file)return sendJson(res,400,{error:'Bad request'});fs.stat(file,(err,st)=>{const candidate=!err&&st.isFile()?file:path.join(root,'index.html');fs.readFile(candidate,(e,data)=>{if(e){res.writeHead(500);return res.end('Server error')}res.writeHead(200,{'Content-Type':types[path.extname(candidate)]||'application/octet-stream','Cache-Control':'no-cache'});res.end(data)})})}catch(e){if(!res.headersSent)sendJson(res,500,{error:'Internal server error'})}});
server.listen(port,'0.0.0.0',()=>console.log(`CRYPTONVA production-shaped server listening on http://0.0.0.0:${port}`));
